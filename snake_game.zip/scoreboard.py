from turtle import Turtle
class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.score=0
        self.goto(0,260)
        self.hideturtle()
        self.color("white")
        self.updatescore()
    def updatescore(self):
        self.write(f"Score:{self.score}", align="center",font=("Arial",24,"normal"))
    def clearscore(self):
        self.clear()
    def refresh(self):
        if(self.score%5==0 and self.score!=0):
            self.score+=6
            self.clearscore()
            self.updatescore()
        else:
            self.score+=1
            self.clearscore()
            self.updatescore()
    def gameover(self):
        self.goto(0,0)
        self.write("Game Over",align="center",font=("Arial",24,"normal"))