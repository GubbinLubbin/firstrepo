from turtle import Turtle
class Snake:
    def __init__(self):
        self.seg_pos=[(0,0),(-15,0),(-30,0)]
        self.all_segments=[]
        self.make_snake()
        self.head=self.all_segments[0]
    def make_snake(self):
        for i in self.seg_pos:
            segment=Turtle()
            segment.shape("square")
            segment.color("white")
            segment.shapesize(0.75)
            segment.penup()
            segment.goto(i)
            self.all_segments.append(segment)
    def move_snake(self):
        for seg_num in range(len(self.all_segments)-1,0,-1):
            new_x=self.all_segments[seg_num-1].xcor()
            new_y=self.all_segments[seg_num-1].ycor()
            self.all_segments[seg_num].goto(new_x,new_y)
        self.head.forward(15)
    def increase_size(self):
        xpos=self.all_segments[len(self.all_segments)-1].xcor()
        ypos=self.all_segments[len(self.all_segments)-1].ycor()
        segment=Turtle()
        segment.shape("square")
        segment.color("white")
        segment.shapesize(0.75)
        segment.penup()
        segment.goto(xpos,ypos)
        self.all_segments.append(segment)
        

    def up(self):
        if(self.head.heading()!=270):
            self.head.setheading(90)
    def down(self):
        if(self.head.heading()!=90):
            self.head.setheading(270)
    def right(self):
        if(self.head.heading()!=180):
            self.head.setheading(0)
    def left(self):
        if(self.head.heading()!=0):
            self.head.setheading(180)    
